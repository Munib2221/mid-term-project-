package com.example.mid_project;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
