import 'package:flutter/material.dart';
import 'home.dart';


void main() {
  runApp(FitnessApp());
}

class FitnessApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Fitness App',

      theme: ThemeData(
        primarySwatch:Colors.green,
      ),
      debugShowCheckedModeBanner: false,
     home: HomeScreen(),

    );
  }
}