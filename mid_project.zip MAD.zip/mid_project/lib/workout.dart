import 'package:flutter/material.dart';

class WorkoutScreen extends StatefulWidget {
  @override
  _WorkoutScreenState createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  bool isWorkingOut = false;
  int workoutCount = 0;

  void toggleWorkout() {
    setState(() {
      isWorkingOut = !isWorkingOut;
      if (!isWorkingOut) {
        workoutCount++;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Workout'),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              isWorkingOut ? 'You are working out!' : 'Take a break!',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: toggleWorkout,
              child: Text(isWorkingOut ? 'Stop Workout' : 'Start Workout'),
            ),
            SizedBox(height: 20),
            Text('Workouts Completed: $workoutCount'),
          ],
        ),
      ),
    );
  }
}