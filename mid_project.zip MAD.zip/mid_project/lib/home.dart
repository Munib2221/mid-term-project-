  import 'package:flutter/material.dart';
  import 'package:mid_project/progress.dart';
  import 'package:mid_project/workout.dart';

  class HomeScreen extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Fitness'),
          backgroundColor: Colors.lightBlueAccent,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement (
                  context,MaterialPageRoute(builder: (context) => WorkoutScreen()),
        );
                },
                child: Text('Start Workout'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                      context,MaterialPageRoute(builder: (context) => ProgressScreen()),
        );
                },
                child: Text('View Progress'),
              ),
            ],
          ),
        ),
      );
    }
  }